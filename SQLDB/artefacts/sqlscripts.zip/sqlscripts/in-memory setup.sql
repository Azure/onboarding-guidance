-- If the tables or stored procedure already exist, drop them to start clean.
IF EXISTS (SELECT NAME FROM sys.objects WHERE NAME = 'DiskBasedTable')
   DROP TABLE [dbo].[DiskBasedTable]
GO

IF EXISTS (SELECT NAME FROM sys.objects WHERE NAME = 'InMemTable')
   DROP TABLE [dbo].[InMemTable]
GO

IF EXISTS (SELECT NAME FROM sys.objects  WHERE NAME = 'InMemTable2')
   DROP TABLE [dbo].[InMemTable2]
GO

IF EXISTS (SELECT NAME FROM sys.objects  WHERE NAME = 'usp_InsertData')
   DROP PROCEDURE [dbo].[usp_InsertData]
GO

-- Create a traditional disk-based table.
CREATE TABLE [dbo].[DiskBasedTable] (
  c1 INT NOT NULL PRIMARY KEY,
  c2 NCHAR(48) NOT NULL
)
GO

-- Create a memory-optimized table.
CREATE TABLE [dbo].[InMemTable] (
  c1 INT NOT NULL PRIMARY KEY NONCLUSTERED HASH WITH (BUCKET_COUNT=1000000),
  c2 NCHAR(48) NOT NULL
) WITH (MEMORY_OPTIMIZED=ON, DURABILITY = SCHEMA_AND_DATA);
GO

-- Create a 2nd memory-optimized table.
CREATE TABLE [dbo].[InMemTable2] (
  c1 INT NOT NULL PRIMARY KEY NONCLUSTERED HASH WITH (BUCKET_COUNT=1000000),
  c2 NCHAR(48) NOT NULL
) WITH (MEMORY_OPTIMIZED=ON, DURABILITY = SCHEMA_AND_DATA);
GO

-- Create a natively-compiled stored procedure.
CREATE PROCEDURE [dbo].[usp_InsertData] 
  @rowcount INT,
  @c NCHAR(48)
  WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
  AS 
  BEGIN ATOMIC 
  WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english')
  DECLARE @i INT = 1;
  WHILE @i <= @rowcount
  BEGIN
    INSERT INTO [dbo].[inMemTable2](c1,c2) VALUES (@i, @c);
    SET @i += 1;
  END
END
GO


--next:


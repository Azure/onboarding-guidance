
--MUST SWITCH CONTEXT TO A USER DATABASE


SET STATISTICS TIME OFF;
SET NOCOUNT ON;

-- Delete data from all tables to reset the example.
DELETE FROM [dbo].[DiskBasedTable] 
    WHERE [c1]>0
GO
DELETE FROM [dbo].[inMemTable] 
    WHERE [c1]>0
GO
DELETE FROM [dbo].[InMemTable2] 
    WHERE [c1]>0
GO

-- Declare parameters for the test queries.
DECLARE @i INT = 1;
DECLARE @rowcount INT = 10000;
DECLARE @c NCHAR(48) = N'12345678901234567890123456789012345678';
DECLARE @timems INT;
DECLARE @starttime datetime2 = sysdatetime();

-- Disk-based table queried with interpreted Transact-SQL.
BEGIN TRAN
  WHILE @I <= @rowcount
  BEGIN
    INSERT INTO [dbo].[DiskBasedTable](c1,c2) VALUES (@i, @c);
    SET @i += 1;
  END
COMMIT



SET @timems = datediff(ms, @starttime, sysdatetime());
SELECT CAST(@timems AS VARCHAR(10)) + ' ms (disk-based table with interpreted Transact-SQL).';

-- Memory-optimized table queried with interpreted Transact-SQL.
SET @i = 1;
SET @starttime = sysdatetime();

BEGIN TRAN
  WHILE @i <= @rowcount
    BEGIN
      INSERT INTO [dbo].[InMemTable](c1,c2) VALUES (@i, @c);
      SET @i += 1;
    END
COMMIT



SET @timems = datediff(ms, @starttime, sysdatetime());
SELECT CAST(@timems AS VARCHAR(10)) + ' ms (memory-optimized table with interpreted Transact-SQL).';


-- Memory-optimized table queried with a natively-compiled stored procedure.
SET @starttime = sysdatetime();

EXEC usp_InsertData @rowcount, @c;

SET @timems = datediff(ms, @starttime, sysdatetime());
SELECT CAST(@timems AS VARCHAR(10)) + ' ms (memory-optimized table with natively-compiled stored procedure).';
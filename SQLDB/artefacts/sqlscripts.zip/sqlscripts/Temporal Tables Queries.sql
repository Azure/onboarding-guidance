-- RUN THESE 1 BY 1

-- YOU NEED TO ALTER THE TIME FRAME IN THE OTHER QUERIES !!!!

-- query the table
select * from Department

update department set DeptName = 'UpdatedDept3' where DeptName = 'department 3'

-- query the table
select * from Department

-- direct query of the history table
select * from History.DepartmentHistory

-- time travel query
select * from Department for SYSTEM_TIME AS OF '2017-06-29 13:53'


-- just show me deltas
select * from Department
EXCEPT
select * from Department for SYSTEM_TIME AS OF '2017-06-29 13:53'


-- show me what the data looked like between these dates
select * from department for SYSTEM_TIME BETWEEN '2017-06-29 13:52' AND '2017-06-29 13:54' 


-- query the table including history, hilighting the differences
Select DeptID, DeptName ValidFrom, ValidTo, IIF(YEAR(ValidTo) = 9999, 1, 0) As IsActual
from Department
for SYSTEM_TIME BETWEEN '2017-06-29 13:52' AND '2017-06-29 13:54'
order by ValidFrom desc
Create Schema History;
GO

-- Standard Table Syntax
CREATE TABLE dbo.department
(
	-- Standard Column Def
	DeptID int IDENTITY(1,1) NOT NULL,
	DeptName varchar(50) NOT NULL,

	-- Need a primary key
	CONSTRAINT PK_Department PRIMARY KEY CLUSTERED (DeptID ASC),

	--NEW TEMPORAL SYNTAX

	-- Add columns for dates and times, can't be NULL and much be this data type
	ValidFrom datetime2(0)  GENERATED ALWAYS AS ROW START NOT NULL,
	ValidTo datetime2(0) GENERATED ALWAYS AS ROW END  NOT NULL,

	-- Tell Temporal mechanism that these cols are the ones to make use of
	PERIOD FOR SYSTEM_TIME (ValidFrom, ValidTo)
)

-- Now turn on time travel saying which history table to use
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE = History.DepartmentHistory))
GO

insert into department (DeptName) VALUES ('department 1');
insert into department (DeptName) VALUES ('department 2');
insert into department (DeptName) VALUES ('department 3');
insert into department (DeptName) VALUES ('department 4');
insert into department (DeptName) VALUES ('department 5');


/*

	Note that history table doesn;t need to exist first, but schema will be checked for compatability if it does
	History can be in a different schema if you like.
	If not specified, System creates a table for you

*/
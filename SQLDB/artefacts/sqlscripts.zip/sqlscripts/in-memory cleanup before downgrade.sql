IF EXISTS (SELECT NAME FROM sys.objects  WHERE NAME = 'usp_InsertData')
   DROP PROCEDURE [dbo].[usp_InsertData]
GO

IF EXISTS (SELECT NAME FROM sys.objects WHERE NAME = 'DiskBasedTable')
   DROP TABLE [dbo].[DiskBasedTable]
GO

IF EXISTS (SELECT NAME FROM sys.objects WHERE NAME = 'InMemTable')
   DROP TABLE [dbo].[InMemTable]
GO

IF EXISTS (SELECT NAME FROM sys.objects  WHERE NAME = 'InMemTable2')
   DROP TABLE [dbo].[InMemTable2]
GO

